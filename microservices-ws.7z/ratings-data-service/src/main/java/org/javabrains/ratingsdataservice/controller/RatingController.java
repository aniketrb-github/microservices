package org.javabrains.ratingsdataservice.controller;

import java.util.Arrays;

import org.javabrains.ratingsdataservice.model.Rating;
import org.javabrains.ratingsdataservice.model.UserRatingsTO;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 
 * @author abharsakale
 *
 */
@RestController
@RequestMapping("/ratingsdata")
public class RatingController {

	@RequestMapping("/{userId}")
	public Rating getRating(@PathVariable String userId) {
		return new Rating(1523, 3.6f);
	}

	// For a user, return all ratings for all his watched movies
	@RequestMapping("/users/{userId}")
	public UserRatingsTO getRatingsList(@PathVariable String userId) {
		UserRatingsTO ratingsTO = new UserRatingsTO();
		ratingsTO.setRatingsList(Arrays.asList(new Rating(1523, 3.9f), new Rating(1524, 4.6f), new Rating(1525, 2.9f)));
		return ratingsTO;
	}

}
